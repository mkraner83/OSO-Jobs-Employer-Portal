# Changelog - OSO Jobs Employer Extension

## [v1.3.1] - December 23, 2025
- Project restored to December 12, 2025 session (v1.0.37-session-end)
- Fixed: Long URLs in "Application Instructions" field now break lines
- Rebuilt and pushed updated employer plugin zip

## [v1.3.0] - December 12, 2025
- Complete Jobseeker Approval System
- Inline Approval Toggle
- Color-Coded Badges
- Email Notifications
- Access Control
- Employer Registration & Profile Management
- Jobseeker Browser & Filtering
- Job Posting System
- File Uploads & Media Library Integration
- Styled HTML Emails
